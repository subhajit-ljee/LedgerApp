package profile.addusers.dao;

public interface UserDao {
    void saveUser();
}
