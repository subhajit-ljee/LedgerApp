package profile.addusers.service;

public interface UserService {
    void saveUser();
}
