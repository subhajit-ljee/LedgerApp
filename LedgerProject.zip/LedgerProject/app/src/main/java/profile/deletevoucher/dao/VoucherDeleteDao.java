package profile.deletevoucher.dao;

public interface VoucherDeleteDao {
    void deleteVoucher();
}
