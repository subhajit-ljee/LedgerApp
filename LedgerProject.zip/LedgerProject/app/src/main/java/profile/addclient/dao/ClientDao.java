package profile.addclient.dao;

import com.google.firebase.firestore.Query;


public interface ClientDao {
    String saveClient();
}
