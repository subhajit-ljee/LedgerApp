package profile.addvoucher.notification.model;

public class MyResponse {
    public int success;
}
