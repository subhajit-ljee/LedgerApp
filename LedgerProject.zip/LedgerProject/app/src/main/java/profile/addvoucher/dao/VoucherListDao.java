package profile.addvoucher.dao;

import com.google.firebase.firestore.Query;

public interface VoucherListDao {
    Query getVoucher();
}
