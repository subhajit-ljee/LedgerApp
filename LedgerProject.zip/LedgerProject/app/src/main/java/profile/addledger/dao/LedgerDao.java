package profile.addledger.dao;

public interface LedgerDao {
    void saveLedger();
}
