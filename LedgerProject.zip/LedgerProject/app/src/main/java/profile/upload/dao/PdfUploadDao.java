package profile.upload.dao;

public interface PdfUploadDao {
    void saveFile();
}
