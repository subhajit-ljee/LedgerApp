package profile.upload.dao;

import com.google.firebase.firestore.Query;

public interface CheckQRDao {
    Query checkQRCode();
}
