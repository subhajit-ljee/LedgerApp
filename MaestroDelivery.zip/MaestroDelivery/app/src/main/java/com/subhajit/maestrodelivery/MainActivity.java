package com.subhajit.maestrodelivery;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.subhajit.maestrodelivery.home.HomeActivity;

public class MainActivity extends BaseActivity {

    private static final String TAG = "MainActivity";

    private EditText useremail;
    private EditText userpassword;

    private SignInButton signInButton;
    private GoogleSignInClient googleSignInClient;
    public static final int RC_SIGN_IN = 0;

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(this, HomeActivity.class);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if(account != null){
            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        useremail = findViewById(R.id.user_name_edit_text);
        userpassword = findViewById(R.id.user_password_edit_text);
        signInButton = findViewById(R.id.google_sign_in_button);

        useremail.setOnFocusChangeListener( (l ,hasFocus) -> {
            if(l.getId() == R.id.user_name_edit_text){
                l.setBackgroundResource(hasFocus ? R.drawable.sign_in_edit_text_design:R.drawable.sign_in_text_design_without_border);
            }
        });

        userpassword.setOnFocusChangeListener( (l ,hasFocus) -> {
            if(l.getId() == R.id.user_password_edit_text){
                l.setBackgroundResource(hasFocus ? R.drawable.sign_in_edit_text_design:R.drawable.sign_in_text_design_without_border);
            }
        });

        signInButton.setOnClickListener( v -> {
            signIn();
        });

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this,gso);
    }

    private void signIn() {
        Intent signInIntent = googleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> task) {
        try {
            GoogleSignInAccount account = task.getResult(ApiException.class);
            String idToken = account.getIdToken();

            // TODO(developer): send ID Token to server and validate

            updateUI(account);
        } catch (ApiException e) {
            Log.w(TAG, "handleSignInResult:error", e);
            updateUI(null);
        }
    }

    private void updateUI(GoogleSignInAccount account) {
        Intent intent = new Intent(this,HomeActivity.class);
        startActivity(intent);
    }

}