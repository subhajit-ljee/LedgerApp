package com.subhajit.maestrodelivery.home;

import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.subhajit.maestrodelivery.BaseActivity;
import com.subhajit.maestrodelivery.R;

public class HomeActivity extends BaseActivity {

    private BottomNavigationView homeNavigationView;

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_activity_home);

        homeNavigationView = findViewById(R.id.home_menu_nav_view);
        setUpBottomNavigation(homeNavigationView);
        homeNavigationView.setItemIconTintList(null);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void setUpBottomNavigation(BottomNavigationView bottomNavigationView){
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            selectDrawerItem(item);
            return true;
        });
    }

    private void selectDrawerItem(MenuItem item) {

        switch (item.getItemId()){
            case R.id.menu_profile:
                profilePage();
                break;
            case R.id.menu_offers:
                offersPage();
                break;
            case R.id.menu_cart:
                cartPage();
                break;
            case R.id.menu_explore:
                explorePage();
                break;
        }
        item.setChecked(true);
    }

    private void profilePage(){}
    private void offersPage(){}
    private void cartPage(){}
    private void explorePage(){}
}
